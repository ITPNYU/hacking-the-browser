# Firebase Clicks Counter

This is an extension that counts the number of times anyone that has installed the
extension has clicked its browser action.

It builds on the [firebase-starter-template](../firebase-starter-template) extension.
