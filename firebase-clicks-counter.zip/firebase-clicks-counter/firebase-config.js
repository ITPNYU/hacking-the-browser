/*

  INSTRUCTIONS: Remove the config below and paste in the
  one provided to you by Firebase.

 */
var config = {
  apiKey: 'AIzaSyBi5U3k8yb09Oenki-r0fEuNMswqgehDXI',
  authDomain: 'htb-2019.firebaseapp.com',
  databaseURL: 'https://htb-2019.firebaseio.com',
  projectId: 'htb-2019',
  storageBucket: 'htb-2019.appspot.com',
  messagingSenderId: '488028042916'
};
